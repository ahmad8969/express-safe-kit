import express, { Router } from "express";
import type { ExpressSafeKitOptions } from "./types";
import { corsMiddleware } from "./middleware/cors";
import { errorHandler } from "./middleware/errorHandler";
import { notFoundHandler } from "./middleware/notFoundHandler";
import { rateLimiter } from "./middleware/rateLimiter";
import { requestLogger } from "./middleware/requestLogger";
import { responseHelpers } from "./middleware/responseHelpers";
import { securityHeaders } from "./middleware/securityHeaders";
import { resolveOptions } from "./utils/resolveOptions";

export const expressSafeKit = (options: ExpressSafeKitOptions = {}) => {
  const resolved = resolveOptions(options);
  const router = Router();

  if (resolved.security.enabled) {
    router.use(securityHeaders(resolved.security));
  }

  if (resolved.cors.enabled) {
    router.use(corsMiddleware(resolved.cors));
  }

  if (resolved.rateLimit.enabled) {
    router.use(rateLimiter(resolved.rateLimit));
  }

  if (resolved.jsonBody.enabled) {
    router.use(express.json({ limit: resolved.jsonBody.limit }));
  }

  if (resolved.urlencodedBody.enabled) {
    router.use(
      express.urlencoded({ extended: resolved.urlencodedBody.extended })
    );
  }

  if (resolved.requestLogger.enabled) {
    router.use(requestLogger(resolved.requestLogger));
  }

  router.use(responseHelpers());
  return router;
};

export {
  responseHelpers,
  rateLimiter,
  requestLogger,
  errorHandler,
  notFoundHandler,
  securityHeaders,
  corsMiddleware
};

export type {
  ApiErrorResponse,
  ApiSuccessResponse,
  CorsOptions,
  CorsOrigin,
  ErrorWithStatusCode,
  ExpressSafeKitOptions,
  ExpressSafeKitResolvedOptions,
  JsonBodyOptions,
  RateLimiterOptions,
  RequestLoggerOptions,
  SecurityHeadersOptions,
  UrlencodedBodyOptions
} from "./types";
