# Package Size Report — express-safe-kit

**Date:** 2026-06-02  
**Version:** 0.1.0  
**Command:** `npm pack --dry-run`

## Tarball summary

| Metric | Value |
|--------|-------|
| **Packed size** | **16.9 kB** |
| **Unpacked size** | **101.1 kB** |
| **Total files** | 9 |

## Included files (published)

| File | Size (approx) |
|------|----------------|
| `LICENSE` | 1.1 kB |
| `README.md` | 10.2 kB |
| `dist/index.js` | 12.1 kB (ESM) |
| `dist/index.js.map` | 27.2 kB |
| `dist/index.cjs` | 14.1 kB (CJS) |
| `dist/index.cjs.map` | 27.3 kB |
| `dist/index.d.ts` | 3.6 kB |
| `dist/index.d.cts` | 3.6 kB |
| `package.json` | 1.8 kB |

## Excluded (not in tarball)

| Path | Reason |
|------|--------|
| `src/` | Source — not in `files` field |
| `tests/` | Dev only |
| `coverage/` | Dev only |
| `examples/` | Not published |
| `docs/` | Not published (except README) |
| `.github/` | Not published |
| `scripts/` | Not published |
| `src/middleware/roadmap/` | Not imported by entry — not in dist |

## Consumer install impact

- **Runtime install:** ~17 KB compressed (+ express peer)
- **Zero runtime dependencies** from this package
- Source maps included for debugging (optional strip in future if size critical)

## Comparison (order of magnitude)

| Package | Typical install |
|---------|-----------------|
| helmet | ~50 KB+ |
| express-rate-limit | ~30 KB+ |
| cors | ~20 KB+ |
| **express-safe-kit** | **~17 KB packed** (all-in-one) |

## Recommendations

1. Keep `files` whitelist strict — do not add `src/` or `examples/`.
2. Source maps are valuable for v0.1.x; consider separate `@express-safe-kit/*` if package grows.
3. Monitor packed size on each release via `npm pack --dry-run`.

## Verdict

**Excellent size profile for an all-in-one middleware kit.**
